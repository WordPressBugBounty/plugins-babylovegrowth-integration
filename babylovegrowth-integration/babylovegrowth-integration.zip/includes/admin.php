<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
	add_options_page(__('BabyLoveGrowth Integration', 'babylovegrowth-integration'), __('BabyLoveGrowth Integration', 'babylovegrowth-integration'), 'manage_options', 'babylovegrowth-integration', 'babylovegrowth_integration_settings_page');
});

add_action('admin_init', function () {
	register_setting('babylovegrowth_integration', 'babylovegrowth_api_key', [
		'sanitize_callback' => function ($val) { return sanitize_text_field($val); }
	]);
	register_setting('babylovegrowth_integration', 'babylovegrowth_category', [
		'sanitize_callback' => function ($val) { return absint($val); }
	]);
	register_setting('babylovegrowth_integration', 'babylovegrowth_tags', [
		'sanitize_callback' => function ($val) {
			if (!is_array($val)) return [];
			return array_map('absint', $val);
		}
	]);
	register_setting('babylovegrowth_integration', 'babylovegrowth_feature_image_enabled', [
		'type' => 'boolean',
		'default' => true,
		'sanitize_callback' => function ($val) { return (bool) $val; }
	]);
});

function babylovegrowth_integration_settings_page() {
	if (!current_user_can('manage_options')) return;

	if (isset($_POST['babylovegrowth_generate_key']) && check_admin_referer('babylovegrowth_generate_key_action')) {
		update_option('babylovegrowth_api_key', wp_generate_password(32, false, false));
		echo '<div class="updated"><p>' . esc_html__('New API key generated.', 'babylovegrowth-integration') . '</p></div>';
	}

	$key = get_option('babylovegrowth_api_key', '');
	$selected_category = get_option('babylovegrowth_category', '');
	$selected_tags = get_option('babylovegrowth_tags', []);
	$feature_image_enabled = get_option('babylovegrowth_feature_image_enabled', true);
	$categories = get_categories(['hide_empty' => false]);
	$tags = get_tags(['hide_empty' => false]);
	?>
	<div class="wrap">
		<h1><?php echo esc_html__('BabyLoveGrowth Integration', 'babylovegrowth-integration'); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields('babylovegrowth_integration'); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="babylovegrowth_api_key"><?php echo esc_html__('API Key', 'babylovegrowth-integration'); ?></label></th>
					<td>
						<input type="text" id="babylovegrowth_api_key" name="babylovegrowth_api_key" value="<?php echo esc_attr($key); ?>" class="regular-text" />
						<p class="description"><?php echo esc_html__('Use this as Bearer token in your BabyLoveGrowth Webhook Integration.', 'babylovegrowth-integration'); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="babylovegrowth_webhook_endpoint"><?php echo esc_html__('Webhook Endpoint', 'babylovegrowth-integration'); ?></label></th>
					<td>
						<input type="text" id="babylovegrowth_webhook_endpoint" value="<?php echo esc_attr( rest_url('babylovegrowth/v1/publish') ); ?>" class="regular-text code" readonly />
						<p class="description"><?php echo esc_html__('Add this URL in BabyLoveGrowth Webhook settings.', 'babylovegrowth-integration'); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="babylovegrowth_category"><?php echo esc_html__('Default Category', 'babylovegrowth-integration'); ?></label></th>
					<td>
						<select id="babylovegrowth_category" name="babylovegrowth_category">
							<option value=""><?php echo esc_html__('— Select Category —', 'babylovegrowth-integration'); ?></option>
							<?php foreach ($categories as $category) : ?>
								<option value="<?php echo esc_attr($category->term_id); ?>" <?php selected($selected_category, $category->term_id); ?>>
									<?php echo esc_html($category->name); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php echo esc_html__('All published posts will be assigned to this category.', 'babylovegrowth-integration'); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="babylovegrowth_tags"><?php echo esc_html__('Default Tags', 'babylovegrowth-integration'); ?></label></th>
					<td>
						<select id="babylovegrowth_tags" name="babylovegrowth_tags[]" multiple size="10" style="width: 25em; height: 150px;">
							<?php if (empty($tags)) : ?>
								<option value="" disabled><?php echo esc_html__('No tags available', 'babylovegrowth-integration'); ?></option>
							<?php else : ?>
								<?php foreach ($tags as $tag) : ?>
									<option value="<?php echo esc_attr($tag->term_id); ?>" <?php selected(in_array($tag->term_id, $selected_tags)); ?>>
										<?php echo esc_html($tag->name); ?>
									</option>
								<?php endforeach; ?>
							<?php endif; ?>
						</select>
						<p class="description"><?php echo esc_html__('Hold Ctrl (or Cmd on Mac) to select multiple tags. All published posts will be assigned these tags.', 'babylovegrowth-integration'); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="babylovegrowth_feature_image_enabled"><?php echo esc_html__('Enable Featured Image', 'babylovegrowth-integration'); ?></label></th>
					<td>
						<label>
							<input type="checkbox" id="babylovegrowth_feature_image_enabled" name="babylovegrowth_feature_image_enabled" value="1" <?php checked($feature_image_enabled, true); ?> />
							<?php echo esc_html__('Remove first H1 and first image from content when hero image is provided', 'babylovegrowth-integration'); ?>
						</label>
						<p class="description"><?php echo esc_html__('When enabled and a hero image is sent, the first H1 heading and first image will be removed from the post content to avoid duplication with the featured image.', 'babylovegrowth-integration'); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button('Save Changes'); ?>
		</form>
		<form method="post" style="margin-top:12px;">
			<?php wp_nonce_field('babylovegrowth_generate_key_action'); ?>
			<?php submit_button(__('Generate New API Key', 'babylovegrowth-integration'), 'secondary', 'babylovegrowth_generate_key'); ?>
		</form>
	</div>
	<?php
}


