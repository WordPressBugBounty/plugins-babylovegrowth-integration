# BabyLoveGrowth Integration Plugin

WordPress plugin for integrating BabyLoveGrowth services.

## SVN Repository (`babylovegrowth-integration-svn`)

This is the **WordPress.org SVN repository** for the plugin. It contains:
- `trunk/` - Current development version (always the latest)
- `tags/` - Released versions (1.0.0, 1.0.1, etc.) - these are downloadable
- `assets/` - Plugin banners, icons, screenshots for WordPress.org
- `branches/` - Feature branches (if needed)

**Important:** 
- Only commit **ready-to-release** code to SVN
- The `trunk/` folder should always contain the latest stable version
- Create tags for each release to make them downloadable
- Assets are shared across all versions

## Development Workflow

### Making Changes

1. **Edit your code** in this directory (`blg-wordpress-plugin/`)
2. **Test locally** before releasing
3. **Update version numbers** in both files:
   - `babylovegrowth-integration.php` (Plugin header: `Version: X.Y.Z`)
   - `readme.txt` (Stable tag: `X.Y.Z` and changelog)

### Releasing New Versions

1. **Copy changes to SVN working copy:**
   ```bash
   rsync -av --delete \
     --exclude='.git' --exclude='.github' --exclude='node_modules' --exclude='README.md' \
     blg-wordpress-plugin/ \
     ../babylovegrowth-integration-svn/trunk/
   ```

2. **Commit to trunk:**
   ```bash
   cd ../babylovegrowth-integration-svn
   svn ci -m "Update to version X.Y.Z" --username meetcpatel8850
   ```

3. **Create new tag (this makes it downloadable):**
   ```bash
   svn copy trunk tags/X.Y.Z
   svn ci -m "Tag version X.Y.Z" --username meetcpatel8850
   ```

### Adding/Updating Assets

1. **Place files in SVN assets folder:**
   ```bash
   # Copy your assets to:
   ../babylovegrowth-integration-svn/assets/
   ```

2. **Add and commit:**
   ```bash
   cd ../babylovegrowth-integration-svn
   svn add assets/*.png assets/*.jpg assets/*.svg
   svn ci -m "Update plugin assets" --username meetcpatel8850
   ```

### Important Files

- **Main plugin file:** `babylovegrowth-integration.php`
- **WordPress.org readme:** `readme.txt` (determines your plugin page)
- **SVN repository:** `../babylovegrowth-integration-svn/` (sibling directory)
- **Plugin page:** https://wordpress.org/plugins/babylovegrowth-integration

### Quick Commands

```bash
# Check SVN status
cd ../babylovegrowth-integration-svn
svn status

# View recent commits
svn log -l 5

# Update from remote (if needed)
svn update
```

### Version Numbering

Use semantic versioning: `MAJOR.MINOR.PATCH`
- **PATCH** (1.0.1): Bug fixes
- **MINOR** (1.1.0): New features, backward compatible
- **MAJOR** (2.0.0): Breaking changes

### Quality Checks (Optional)

```bash
# PHP Code Standards (if you have PHPCS installed)
vendor/bin/phpcs --standard=WordPress --extensions=php .

# Plugin Check (WordPress admin tool)
# Install "Plugin Check" plugin in WordPress admin
```

---

**Remember:** Always test locally before releasing to WordPress.org!
